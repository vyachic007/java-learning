#!/bin/bash
java -jar HotelAdmin.jar
