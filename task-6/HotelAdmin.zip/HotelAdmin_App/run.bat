@echo off
java -jar HotelAdmin.jar
pause
